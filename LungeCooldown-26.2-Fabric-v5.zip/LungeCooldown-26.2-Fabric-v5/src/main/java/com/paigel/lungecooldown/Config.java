package com.paigel.lungecooldown;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static final String FILE_NAME = "lungecooldown.properties";
    private static final double DEFAULT_COOLDOWN_SECONDS = 30.0;
    private static final boolean DEFAULT_ACTIONBAR_MESSAGE = true;

    private static double cooldownSeconds = DEFAULT_COOLDOWN_SECONDS;
    private static boolean actionbarMessage = DEFAULT_ACTIONBAR_MESSAGE;

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
        Properties properties = new Properties();

        try {
            Files.createDirectories(path.getParent());
            if (Files.notExists(path)) {
                saveDefaults(path);
            }

            try (InputStream in = Files.newInputStream(path)) {
                properties.load(in);
            }

            cooldownSeconds = parseCooldown(
                    properties.getProperty("cooldown_seconds", String.valueOf(DEFAULT_COOLDOWN_SECONDS))
            );
            actionbarMessage = Boolean.parseBoolean(
                    properties.getProperty("actionbar_message", String.valueOf(DEFAULT_ACTIONBAR_MESSAGE))
            );
        } catch (IOException exception) {
            cooldownSeconds = DEFAULT_COOLDOWN_SECONDS;
            actionbarMessage = DEFAULT_ACTIONBAR_MESSAGE;
            System.err.println("[LungeCooldown] Failed to load config: " + exception.getMessage());
        }
    }

    private static double parseCooldown(String raw) {
        try {
            double value = Double.parseDouble(raw.trim());
            if (!Double.isFinite(value) || value < 0.0) {
                throw new NumberFormatException("must be finite and >= 0");
            }
            return value;
        } catch (NumberFormatException exception) {
            System.err.println("[LungeCooldown] Invalid cooldown_seconds='" + raw + "'; using 30.0.");
            return DEFAULT_COOLDOWN_SECONDS;
        }
    }

    private static void saveDefaults(Path path) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("cooldown_seconds", String.valueOf(DEFAULT_COOLDOWN_SECONDS));
        properties.setProperty("actionbar_message", String.valueOf(DEFAULT_ACTIONBAR_MESSAGE));

        try (OutputStream out = Files.newOutputStream(path)) {
            properties.store(out, "Lunge Cooldown configuration");
        }
    }

    public static double cooldownSeconds() {
        return cooldownSeconds;
    }

    public static boolean actionbarMessage() {
        return actionbarMessage;
    }

    private Config() {
    }
}
