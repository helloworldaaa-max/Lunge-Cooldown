package com.paigel.lungecooldown.mixin;

import com.paigel.lungecooldown.Config;
import com.paigel.lungecooldown.LungeCooldownMod;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.EnchantedItemInUse;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Enchantment.class)
public abstract class EnchantmentMixin {
    @Inject(method = "doPostPiercingAttack", at = @At("HEAD"), cancellable = true)
    private void lungeCooldown$gateLunge(
            ServerLevel serverLevel,
            int enchantmentLevel,
            EnchantedItemInUse item,
            Entity user,
            CallbackInfo ci
    ) {
        if (!(user instanceof ServerPlayer player)) {
            return;
        }

        Enchantment self = (Enchantment) (Object) this;
        Holder<Enchantment> lungeHolder = serverLevel.registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT)
                .getOrThrow(Enchantments.LUNGE);

        if (lungeHolder.value() != self) {
            return;
        }

        // Match the vanilla 26.2 Lunge requirements exactly.
        if (player.isPassenger() || player.isFallFlying() || player.isInWater()) {
            return;
        }
        if (!player.isCreative() && player.getFoodData().getFoodLevel() < 7) {
            return;
        }

        long now = serverLevel.getGameTime();
        long nextAllowed = LungeCooldownMod.nextAllowedTick(player.getUUID());

        if (now < nextAllowed) {
            if (Config.actionbarMessage()) {
                double secondsLeft = (nextAllowed - now) / 20.0;
                player.sendSystemMessage(
                        Component.literal(String.format(java.util.Locale.ROOT,
                                "Lunge cooldown: %.1fs", secondsLeft)),
                        true
                );
            }
            ci.cancel();
            return;
        }

        LungeCooldownMod.setNextAllowedTick(
                player.getUUID(),
                now + LungeCooldownMod.cooldownTicks()
        );
    }
}
