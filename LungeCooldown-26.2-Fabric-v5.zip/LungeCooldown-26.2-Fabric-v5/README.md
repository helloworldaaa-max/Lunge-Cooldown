# Lunge Cooldown — Minecraft 26.2 Fabric

Server-side Fabric mod for Minecraft 26.2 that adds a configurable per-player cooldown to the vanilla **Lunge** enchantment.

## What it changes

- Only the **vanilla Lunge enchantment** is gated.
- The normal spear **Jab attack still works** during the cooldown.
- The vanilla spear Jab's own attack cooldown is untouched.
- The server's existing mace cooldown is untouched.
- Cooldown is per player.
- Cooldown is measured in seconds and can be decimal.
- Optional actionbar message when a Lunge is denied.
- No client mod is required.
- No commands or command-permission API are used.
- No attribute-swapping restriction is added.

The mixin is placed on Minecraft 26.2's `Enchantment.doPostPiercingAttack`, which is the vanilla path that actually runs the Lunge enchantment's `post_piercing_attack` effect. The code also mirrors the vanilla 26.2 Lunge requirements (not riding, not elytra-flying, not in water, and player hunger at least 7 unless creative) so a failed vanilla Lunge attempt does not consume the custom cooldown.

## Build

Minecraft 26.2 uses Java 25 and the 26.2 Fabric toolchain uses Loom 1.17 / Gradle 9.5.1 / Fabric Loader 0.19.3.

In Codespaces:

```bash
java -version
gradle --version
gradle clean build
```

The built jar is in:

```text
build/libs/lungecooldown-1.0.0.jar
```

Put that jar in the server's `mods` folder.

## Config

After the first server start, edit:

```text
config/lungecooldown.properties
```

Example:

```properties
cooldown_seconds=30.0
actionbar_message=true
```

Restart the server after changing the config.

Set `cooldown_seconds=0` to disable the custom cooldown without removing the mod.

## v5 compile hotfix

Minecraft 26.2's `ServerPlayer` uses `sendSystemMessage(Component, boolean)` for an overlay/action-bar message; `displayClientMessage` is not available here. This source has been corrected to use the 26.2 server API.
