# Lunge Cooldown — Minecraft 26.2 Fabric

Server-side Fabric mod for Minecraft 26.2.

## What it does

- Adds a **per-player cooldown to spear Lunge only**.
- Detects the real 26.2 server-side **STAB** packet instead of generic attacks.
- Cooldown is measured in seconds and is configurable.
- Optional action-bar message while the cooldown is active.
- The cooldown belongs to the player, so switching items does not reset it.
- Does **not** change or hook the mace cooldown.
- Does **not** implement its own attribute-swapping mechanic.

## Configuration

After the first server start, edit:

`config/lungecooldown.properties`

Example:

```properties
cooldown_seconds=30.0
actionbar_message=true
```

`cooldown_seconds` may be any finite number greater than or equal to `0`.

Restart the server after changing the file.

## Build in GitHub Codespaces

This project uses the 26.2 Mojang-mapped setup and Java 25.

```bash
gradle clean build
```

The built jar will be in `build/libs/` (named `LungeCooldown-<version>.jar`).

Put that jar in the server's `mods` folder.
