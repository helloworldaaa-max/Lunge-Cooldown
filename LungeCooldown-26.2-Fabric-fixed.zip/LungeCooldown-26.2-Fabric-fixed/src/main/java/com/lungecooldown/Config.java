package com.lungecooldown;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static final String FILE_NAME = "lungecooldown.properties";
    private static final double DEFAULT_COOLDOWN_SECONDS = 30.0;
    private static final boolean DEFAULT_ACTIONBAR_MESSAGE = true;

    private static double cooldownSeconds = DEFAULT_COOLDOWN_SECONDS;
    private static boolean actionbarMessage = DEFAULT_ACTIONBAR_MESSAGE;

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
        Properties properties = new Properties();

        try {
            Files.createDirectories(path.getParent());
            if (Files.notExists(path)) {
                saveDefaults(path);
            }

            try (InputStream in = Files.newInputStream(path)) {
                properties.load(in);
            }

            cooldownSeconds = parseCooldown(properties.getProperty(
                    "cooldown_seconds", Double.toString(DEFAULT_COOLDOWN_SECONDS)));
            actionbarMessage = Boolean.parseBoolean(properties.getProperty(
                    "actionbar_message", Boolean.toString(DEFAULT_ACTIONBAR_MESSAGE)));
        } catch (IOException e) {
            cooldownSeconds = DEFAULT_COOLDOWN_SECONDS;
            actionbarMessage = DEFAULT_ACTIONBAR_MESSAGE;
            System.err.println("[LungeCooldown] Could not read " + path + ": " + e.getMessage());
        }
    }

    private static double parseCooldown(String raw) {
        try {
            double value = Double.parseDouble(raw.trim());
            if (!Double.isFinite(value) || value < 0.0) {
                throw new NumberFormatException("cooldown must be a finite number >= 0");
            }
            return value;
        } catch (NumberFormatException e) {
            System.err.println("[LungeCooldown] Invalid cooldown_seconds='" + raw + "'. Using 30.0 seconds.");
            return DEFAULT_COOLDOWN_SECONDS;
        }
    }

    private static void saveDefaults(Path path) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("cooldown_seconds", Double.toString(DEFAULT_COOLDOWN_SECONDS));
        properties.setProperty("actionbar_message", Boolean.toString(DEFAULT_ACTIONBAR_MESSAGE));
        try (OutputStream out = Files.newOutputStream(path)) {
            properties.store(out, "Lunge Cooldown configuration");
        }
    }

    public static double cooldownSeconds() {
        return cooldownSeconds;
    }

    public static boolean actionbarMessage() {
        return actionbarMessage;
    }

    private Config() {
    }
}
