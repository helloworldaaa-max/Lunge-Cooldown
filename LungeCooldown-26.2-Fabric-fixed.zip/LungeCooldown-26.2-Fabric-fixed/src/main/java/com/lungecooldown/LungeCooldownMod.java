package com.lungecooldown;

import net.fabricmc.api.ModInitializer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LungeCooldownMod implements ModInitializer {
    private static final Map<UUID, Long> NEXT_ALLOWED_TICK = new HashMap<>();

    @Override
    public void onInitialize() {
        Config.load();
    }

    public static long getNextAllowedTick(UUID playerId) {
        return NEXT_ALLOWED_TICK.getOrDefault(playerId, Long.MIN_VALUE);
    }

    public static void setNextAllowedTick(UUID playerId, long tick) {
        NEXT_ALLOWED_TICK.put(playerId, tick);
    }

    private LungeCooldownMod() {
    }
}
