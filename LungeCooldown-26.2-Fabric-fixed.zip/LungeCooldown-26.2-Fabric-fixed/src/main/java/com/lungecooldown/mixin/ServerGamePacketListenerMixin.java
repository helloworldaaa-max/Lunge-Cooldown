package com.lungecooldown.mixin;

import com.lungecooldown.Config;
import com.lungecooldown.LungeCooldownMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerGamePacketListenerImpl;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.PiercingWeapon;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.core.component.DataComponents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Locale;

@Mixin(ServerGamePacketListenerImpl.class)
public abstract class ServerGamePacketListenerMixin {
    @Inject(method = "handlePlayerAction", at = @At("HEAD"), cancellable = true)
    private void lungeCooldown$handlePlayerAction(ServerboundPlayerActionPacket packet, CallbackInfo ci) {
        if (packet.getAction() != ServerboundPlayerActionPacket.Action.STAB) {
            return;
        }

        ServerGamePacketListenerImpl listener = (ServerGamePacketListenerImpl) (Object) this;
        ServerPlayer player = listener.player;

        if (player.isSpectator()) {
            return;
        }

        ItemStack item = player.getItemInHand(InteractionHand.MAIN_HAND);

        // Match vanilla's validation immediately before the STAB attack.
        if (player.cannotAttackWithItem(item, 5)) {
            return;
        }

        PiercingWeapon piercingWeapon = item.get(DataComponents.PIERCING_WEAPON);
        if (piercingWeapon == null) {
            return;
        }

        var enchantmentLookup = player.level().holderLookup(Registries.ENCHANTMENT);
        var lunge = enchantmentLookup.getOrThrow(Enchantments.LUNGE);
        int lungeLevel = EnchantmentHelper.getItemEnchantmentLevel(lunge, item);
        if (lungeLevel <= 0) {
            return;
        }

        // Vanilla Lunge requires at least 6 hunger. Do not start our cooldown if vanilla cannot Lunge.
        if (player.getFoodData().getFoodLevel() < 6) {
            return;
        }

        long now = player.level().getGameTime();
        long nextAllowed = LungeCooldownMod.getNextAllowedTick(player.getUUID());

        if (now < nextAllowed) {
            if (Config.actionbarMessage()) {
                double secondsLeft = (nextAllowed - now) / 20.0;
                player.displayClientMessage(
                        Component.literal(String.format(Locale.ROOT, "Lunge cooldown: %.1fs", secondsLeft)),
                        true
                );
            }
            ci.cancel();
            return;
        }

        long cooldownTicks = Math.max(0L, Math.round(Config.cooldownSeconds() * 20.0));
        LungeCooldownMod.setNextAllowedTick(player.getUUID(), now + cooldownTicks);
    }
}
