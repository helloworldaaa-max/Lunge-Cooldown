package com.paigel.lungecooldown;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("lunge-cooldown.json");

    public static double cooldownSeconds = 30.0;
    public static boolean messageEnabled = true;

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try {
            Data data = GSON.fromJson(Files.readString(FILE), Data.class);
            if (data != null) {
                cooldownSeconds = Math.max(0.0, data.cooldownSeconds);
                messageEnabled = data.messageEnabled;
            }
        } catch (Exception ignored) {
            save();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(new Data(cooldownSeconds, messageEnabled)));
        } catch (IOException ignored) {}
    }

    private record Data(double cooldownSeconds, boolean messageEnabled) {}
}
