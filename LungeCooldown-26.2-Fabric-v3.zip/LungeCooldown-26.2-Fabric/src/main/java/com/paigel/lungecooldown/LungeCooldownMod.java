package com.paigel.lungecooldown;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class LungeCooldownMod implements ModInitializer {
    public static final String MOD_ID = "lunge-cooldown";

    @Override
    public void onInitialize() {
        Config.load();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("lungecooldown")
                .requires(source -> source.permissions().hasPermission(2))
                .then(Commands.literal("set")
                    .then(Commands.argument("seconds", DoubleArgumentType.doubleArg(0.0))
                        .executes(ctx -> {
                            double seconds = DoubleArgumentType.getDouble(ctx, "seconds");
                            Config.cooldownSeconds = seconds;
                            Config.save();
                            ctx.getSource().sendSuccess(() ->
                                Component.literal("Lunge cooldown set to " + format(seconds) + " seconds."), true);
                            return 1;
                        })))
                .then(Commands.literal("get")
                    .executes(ctx -> {
                        double seconds = Config.cooldownSeconds;
                        ctx.getSource().sendSuccess(() ->
                            Component.literal("Lunge cooldown: " + format(seconds) + " seconds."), false);
                        return 1;
                    }))
                .then(Commands.literal("message")
                    .then(Commands.literal("on").executes(ctx -> {
                        Config.messageEnabled = true;
                        Config.save();
                        ctx.getSource().sendSuccess(() -> Component.literal("Cooldown message: ON"), true);
                        return 1;
                    }))
                    .then(Commands.literal("off").executes(ctx -> {
                        Config.messageEnabled = false;
                        Config.save();
                        ctx.getSource().sendSuccess(() -> Component.literal("Cooldown message: OFF"), true);
                        return 1;
                    })))
            );
        });
    }

    private static String format(double seconds) {
        if (seconds == Math.rint(seconds)) return Long.toString((long) seconds);
        return String.format(java.util.Locale.ROOT, "%.2f", seconds);
    }

    public static void showCooldownMessage(ServerPlayer player, double remaining) {
        if (!Config.messageEnabled) return;
        String text = "Lunge on cooldown: " + format(Math.max(0.0, remaining)) + "s";
        player.sendSystemMessage(Component.literal(text));
    }
}
