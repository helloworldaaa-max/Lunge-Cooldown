package com.paigel.lungecooldown.mixin;

import com.paigel.lungecooldown.Config;
import com.paigel.lungecooldown.LungeCooldownMod;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/*
 * Server-side guard for Lunge.
 *
 * 26.2 changed/fixed the old attribute-swap behavior, so the server must
 * enforce the cooldown independently of the item that was visible in the
 * player's hand at the exact attack call. The guard records a Lunge use
 * whenever a Lunge spear is involved in the attack path and blocks repeated
 * uses for that player.
 *
 * The implementation intentionally does NOT modify the normal weapon/mace
 * cooldown.
 */
@Mixin(Player.class)
public abstract class PlayerAttackMixin {
    private static final Map<UUID, Long> NEXT_LUNGE = new HashMap<>();

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void lungeCooldown$check(Entity target, CallbackInfo ci) {
        Player player = (Player) (Object) this;

        if (player.level().isClientSide()) return;

        ItemStack spear = findLungeSpear(player);
        if (spear.isEmpty()) return;

        int lungeLevel = getLungeLevel(player, spear);
        if (lungeLevel <= 0) return;

        long now = player.level().getServer().getTickCount();
        long next = NEXT_LUNGE.getOrDefault(player.getUUID(), 0L);

        if (now < next) {
            if (player instanceof ServerPlayer serverPlayer) {
                LungeCooldownMod.showCooldownMessage(serverPlayer, (next - now) / 20.0);
            }
            ci.cancel();
            return;
        }

        long cooldownTicks = Math.max(0L, Math.round(Config.cooldownSeconds * 20.0));
        NEXT_LUNGE.put(player.getUUID(), now + cooldownTicks);
    }

    /*
     * Attribute swapping can make the item currently selected by the player
     * differ from the item supplying the attack attributes. Search the
     * hotbar as a fallback so a same-tick swap cannot evade the per-player
     * Lunge timer.
     */
    private static ItemStack findLungeSpear(Player player) {
        ItemStack main = player.getMainHandItem();
        if (getLungeLevel(player, main) > 0 && isSpear(main)) return main;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.isEmpty() && isSpear(stack) && getLungeLevel(player, stack) > 0) {
                return stack;
            }
        }
        return ItemStack.EMPTY;
    }

    private static boolean isSpear(ItemStack stack) {
        if (stack.isEmpty()) return false;
        return net.minecraft.core.registries.BuiltInRegistries.ITEM
            .getKey(stack.getItem()).getPath().contains("spear");
    }

    private static int getLungeLevel(Player player, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        try {
            var lookup = player.level().registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT);
            var lunge = lookup.getOrThrow(net.minecraft.world.item.enchantment.Enchantments.LUNGE);
            return EnchantmentHelper.getLevel(lunge, stack);
        } catch (Exception ignored) {
            return 0;
        }
    }
}
