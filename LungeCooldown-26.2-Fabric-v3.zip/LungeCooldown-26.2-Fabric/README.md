# Lunge Cooldown — Minecraft 26.2 Fabric

Server-side Fabric mod intended for Minecraft 26.2.

Features:
- Lunge-only cooldown
- Configurable in seconds
- Per-player cooldown
- Server authoritative
- Does not modify mace cooldowns
- Optional cooldown message
- Default: 30 seconds

Commands (permission level 2 / OP):
- `/lungecooldown set <seconds>`
- `/lungecooldown get`
- `/lungecooldown message on`
- `/lungecooldown message off`

Config:
`config/lunge-cooldown.json`

Important:
This source project was prepared against the official Fabric 26.2 development setup (Loom 1.17, Java 25, Fabric Loader 0.19.3, Fabric API 0.152.2+26.2). The execution environment used to prepare this archive does not have Java 25 or Maven/Fabric dependencies cached and cannot resolve external Maven hosts, so a compiled JAR could not be produced or runtime-tested here.

Build on a machine with Java 25 and internet access:
`./gradlew build`

The output JAR will be in `build/libs/`.


## Attribute-swap protection

The implementation now checks the player's hotbar for a Lunge spear during the
server-side attack path. This is intended to prevent same-tick hotbar/attribute
swapping from avoiding the per-player timer.

Minecraft 26.2 itself changed attribute swapping, so the exact behavior depends
on the final 26.2 server build. Test this on your server by setting a short
cooldown (for example `/lungecooldown set 10`) and trying both normal Lunge and
your attribute-swap technique.
